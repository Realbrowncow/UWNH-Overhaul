#!/usr/bin/env python3
"""Build the single-file, offline, ROM-free Test54c upgrade page.

Only the already-public cumulative IPS is embedded. Original and upgraded game
ROMs are never read by this builder or included in its output.
"""
from __future__ import annotations

import argparse
import base64
import hashlib
from pathlib import Path

PATCH_SHA256 = "b92debc2c64dc10a0570f6da9eca182565b35e13de2caeef125bf4b3eb149286"
PATCH_BYTES = 88565
MARKER = "__EMBEDDED_TEST54C_IPS_BASE64__"


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--ips", type=Path, required=True, help="Verified Test54c cumulative IPS")
    parser.add_argument("--output", type=Path, required=True, help="Public HTML output path")
    args = parser.parse_args()

    patch = args.ips.read_bytes()
    digest = hashlib.sha256(patch).hexdigest()
    if len(patch) != PATCH_BYTES or digest != PATCH_SHA256:
        raise SystemExit("Refusing to build: IPS size or SHA-256 does not match Test54c.")
    if not patch.startswith(b"PATCH") or b"EOF" not in patch:
        raise SystemExit("Refusing to build: invalid IPS markers.")

    template = Path(__file__).with_name("upgrader_template.html").read_text("utf-8")
    if template.count(MARKER) != 1:
        raise SystemExit("Refusing to build: IPS placeholder is not unique.")
    payload = base64.b64encode(patch).decode("ascii")
    html = template.replace(MARKER, payload)
    if not html.startswith("<!doctype html>"):
        raise SystemExit("Unexpected template format.")
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(html, encoding="utf-8")
    print(f"ROM-free public HTML: {args.output}")
    print(f"IPS SHA-256: {digest}")
    print(f"HTML bytes: {args.output.stat().st_size}")
    print(f"HTML SHA-256: {hashlib.sha256(args.output.read_bytes()).hexdigest()}")


if __name__ == "__main__":
    main()
