// Automated ROM-free upgrader audit. The source ROM is supplied privately at test time.
import assert from 'node:assert/strict';
import { readFileSync, mkdirSync } from 'node:fs';
import { resolve } from 'node:path';
import vm from 'node:vm';
import { webcrypto, createHash } from 'node:crypto';
import { createRequire } from 'node:module';
const require = createRequire(import.meta.url);
const { chromium } = require('playwright');

const [htmlFile, sourceFile, screenshotDir] = process.argv.slice(2);
if (!htmlFile || !sourceFile) throw Error('Usage: node test_upgrader.mjs HTML_FILE PRIVATE_CLEAN_US_ROM [SCREENSHOT_DIR]');
const htmlPath = resolve(htmlFile);
const source = new Uint8Array(readFileSync(sourceFile));
const html = readFileSync(htmlPath,'utf8');
const expectedClean='64bc4707f422661a66618088887e2363a5f896ea683c58984fffd96dd21ab5f0';
const expectedPatch='b92debc2c64dc10a0570f6da9eca182565b35e13de2caeef125bf4b3eb149286';
const expectedTarget='924ee53c49d125aa0cd23059d9bbfec42ede83cda50c36f6235431bb0db63a01';
const sha = data => createHash('sha256').update(data).digest('hex');
assert.equal(source.length,2097152);
assert.equal(sha(source),expectedClean);
assert(!html.includes('__EMBEDDED_TEST54C_IPS_BASE64__'));
assert(!html.includes('fetch(') && !html.includes('XMLHttpRequest') && !html.includes('sendBeacon'));
const payload=html.match(/<script id="embeddedTest54cIPS" type="text\/plain">([A-Za-z0-9+/=]+)<\/script>/)?.[1];
assert(payload,'Embedded IPS data is missing');
const patchBytes=new Uint8Array(Buffer.from(payload,'base64'));
assert.equal(patchBytes.length,88565);
assert.equal(sha(patchBytes),expectedPatch);

const appCode=html.match(/<script>\s*("use strict";[\s\S]*?)<\/script>/)?.[1];
assert(appCode,'Application JavaScript is missing');
const fakeDocument={getElementById: id => id==='embeddedTest54cIPS'?{textContent:payload}:null,addEventListener:()=>{}};
const api=vm.runInNewContext(appCode+'\n;UW54Public;',{
  document:fakeDocument,crypto:webcrypto,Uint8Array,atob,
  Blob,URL,setTimeout,console,
},{timeout:2000});

const changed=source.slice();changed[100]=changed[100]^0x01;
await assert.rejects(api.upgradeBytes(changed,patchBytes),/not the verified clean/);
await assert.rejects(api.upgradeBytes(new Uint8Array(2097664),patchBytes),/2 MB/);
await assert.rejects(api.upgradeBytes(new Uint8Array(4194304),patchBytes),/2 MB/);
const changedPatch=patchBytes.slice();changedPatch[123]=changedPatch[123]^0x01;
await assert.rejects(api.upgradeBytes(source,changedPatch),/integrity check failed/);
assert.throws(()=>api.parseAndApplyIPS(source,patchBytes.slice(0,-5)),/end marker|trailing data|Truncated|Invalid/);
const {rom,records,sha256}=await api.upgradeBytes(source,patchBytes);
assert.equal(records,5763);
assert.equal(rom.length,4194304);
assert.equal(sha256,expectedTarget);
assert.equal(sha(rom),expectedTarget);
assert.equal(sha(source),expectedClean,'Original input modified');
console.log('PASS — Node core, exact 5,763 IPS records, correct target SHA, wrong inputs rejected');

// Exercise the same event callbacks without a privileged browser process.
const callbacks={};
const fileInput={files:[],addEventListener:(kind,fn)=>{callbacks['file:'+kind]=fn;}};
const actionButton={disabled:true,addEventListener:(kind,fn)=>{callbacks['button:'+kind]=fn;}};
const statusNode={textContent:'',className:''};
let pendingBlob=null, downloads=[];
const fakeURL={createObjectURL:blob=>{pendingBlob=blob;return 'blob:test-output';},revokeObjectURL:()=>{}};
const fakeAnchor={style:{},click(){downloads.push({name:this.download,blob:pendingBlob});},remove(){}};
const dom={
  getElementById:id=>({originalFile:fileInput,upgradeButton:actionButton,status:statusNode,embeddedTest54cIPS:{textContent:payload}})[id],
  createElement:()=>fakeAnchor,
  body:{appendChild:()=>{}},
  addEventListener:()=>{},
};
const ui=vm.runInNewContext(appCode+'\n;UW54Public;',{
  document:dom,crypto:webcrypto,Uint8Array,atob,Blob,URL:fakeURL,setTimeout:()=>{},console,
},{timeout:2000});
ui.init();
fileInput.files=[{name:'clean.smc',size:source.length,arrayBuffer:async()=>source.buffer.slice(source.byteOffset,source.byteOffset+source.byteLength)}];
callbacks['file:change']();
assert.equal(actionButton.disabled,false);
await callbacks['button:click']();
assert.equal(downloads.length,1);
assert.equal(downloads[0].name,'UWNH_Test54c_from_Clean_US_Verified.smc');
assert.equal(sha(Buffer.from(await downloads[0].blob.arrayBuffer())),expectedTarget);
assert.match(statusNode.textContent,/Success! Verified Test54c/);
fileInput.files=[{name:'wrong.smc',size:source.length,arrayBuffer:async()=>Buffer.alloc(source.length).buffer}];
callbacks['file:change']();
await callbacks['button:click']();
assert.equal(downloads.length,1,'Invalid file must not create a download');
assert.equal(statusNode.className,'error');
console.log('PASS — independent UI events, correct download name/data, invalid files blocked');

let browser;
try {
  browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox']});
} catch (error) {
  const message=String(error?.message||error);
  if (!message.includes('Operation not permitted') && !message.includes('socket() failed')) throw error;
  console.log('PENDING — real Chromium click/download: sandbox forbids browser socket()');
  process.exit(0);
}
try{
  const context=await browser.newContext({acceptDownloads:true,viewport:{width:1180,height:900}});
  const page=await context.newPage();
  const network=[];
  page.on('request',r=>{if(!r.url().startsWith('file:') && !r.url().startsWith('data:') && !r.url().startsWith('blob:')) network.push(r.url());});
  await page.goto('file://'+htmlPath);
  assert.equal(await page.title(),'Test54c ROM Upgrader — Ken Chee (Realbrowncow)');
  assert.equal(await page.locator('#upgradeButton').isDisabled(),true);
  if(screenshotDir){mkdirSync(screenshotDir,{recursive:true});await page.screenshot({path:resolve(screenshotDir,'Test54c_Public_Upgrader_Desktop.png'),fullPage:true});}
  await page.locator('#originalFile').setInputFiles({name:'Uncharted Waters - New Horizons (U).smc',mimeType:'application/octet-stream',buffer:Buffer.from(source)});
  assert.equal(await page.locator('#upgradeButton').isEnabled(),true);
  const [download]=await Promise.all([page.waitForEvent('download',{timeout:40000}),page.locator('#upgradeButton').click()]);
  assert.equal(download.suggestedFilename(),'UWNH_Test54c_from_Clean_US_Verified.smc');
  const saved=readFileSync(await download.path());
  assert.equal(saved.length,4194304);
  assert.equal(sha(saved),expectedTarget);
  const status=await page.locator('#status').textContent();
  assert(status.includes('Success! Verified Test54c ROM created.'));
  assert.equal(network.length,0,'Upgrade should not request network resources');

  let downloadCount=0;page.on('download',()=>downloadCount++);
  await page.locator('#originalFile').setInputFiles({name:'WrongRegion.smc',mimeType:'application/octet-stream',buffer:Buffer.alloc(2097152)});
  await page.locator('#upgradeButton').click();
  await page.locator('#status.error').waitFor({timeout:10000});
  assert((await page.locator('#status').textContent()).includes('not the verified clean US original'));
  assert.equal(downloadCount,0,'Wrong ROM triggered download');
  await page.locator('#originalFile').setInputFiles({name:'HeaderedUS.smc',mimeType:'application/octet-stream',buffer:Buffer.alloc(2097664)});
  await page.locator('#upgradeButton').click();
  await page.locator('#status.error').waitFor({timeout:10000});
  assert.equal(downloadCount,0,'Headered ROM triggered download');
  console.log('PASS — real local-file Chromium UI, downloaded ROM exact, invalid ROMs refused, network requests 0');
  await context.close();
}finally{await browser.close();}
