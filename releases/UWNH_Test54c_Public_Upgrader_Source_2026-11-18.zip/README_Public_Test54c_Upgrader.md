# Test54c — Public ROM-free Upgrader

**Project:** *Uncharted Waters: New Horizons* (US SNES)

**Creator:** Ken Chee (Realbrowncow)

This is the public, beginner-friendly **upgrade companion** to World, Ship & Fleet Studio. It is intentionally separate from the private Beta 5.9 editor, which contains game data and must not be shared.

## For players — no installation required

1. Extract the ZIP file if you received one.
2. Open `UWNH_Test54c_Public_ROM_Free_Upgrader.html` in a current desktop version of Chrome, Edge or Firefox.
3. Click **Select original US ROM** and choose your own legally obtained, unmodified, headerless US *Uncharted Waters: New Horizons* file (`.smc` or `.sfc`, 2,097,152 bytes).
4. Click **Verify and Create Test54c**.
5. Save `UWNH_Test54c_from_Clean_US_Verified.smc` when the browser offers the download. Open the new file in your SNES emulator.

If the wrong file is selected, the tool displays an error and does **not** create a download. The original ROM remains unchanged.

The tool works entirely inside the browser, including when opened offline from your computer. **No ROM is uploaded to a server.** It requires no third-party patcher and does not download additional patch data. A normal web browser is the only software required.

## Exact compatibility

| File | Size (bytes) | SHA-256 |
| --- | ---: | --- |
| Clean, headerless US original | 2,097,152 | `64bc4707f422661a66618088887e2363a5f896ea683c58984fffd96dd21ab5f0` |
| Test54c cumulative IPS (embedded) | 88,565 | `b92debc2c64dc10a0570f6da9eca182565b35e13de2caeef125bf4b3eb149286` |
| Test54c output ROM (generated locally) | 4,194,304 | `924ee53c49d125aa0cd23059d9bbfec42ede83cda50c36f6235431bb0db63a01` |

Wrong-region, modified, copier-headered or incorrect-size ROMs are refused. Test54c is experimental, so starting a new game is recommended; emulator save states from incompatible builds may fail.

## Public release and redistribution

- The `html` file contains only the application code, interface, verification hashes and the **already-public Test54c cumulative IPS**.
- The ZIP contains only this HTML, its instructions and the reusable source builder/template.
- Neither contains an original ROM, a modified ROM, the private integrated Beta 5.9 editor or commercial game assets.
- The patch source is in [Realbrowncow's public repository](https://github.com/Realbrowncow/Uncharted-Waters-New-Horizons-ROM-Research/tree/main/patches/test54c-clean-us).
- Users must supply their own legally obtained copy of the original game.

We recommend offering the ZIP or HTML as **Recommended: Easy Upgrade Tool**, and retaining the independent [IPS patch](https://github.com/Realbrowncow/Uncharted-Waters-New-Horizons-ROM-Research/blob/main/patches/test54c-clean-us/UWNH_Test54c_CUMULATIVE_from_Clean_US_ROM_2026-11-16.ips) as an advanced alternative.

## Rebuilding the HTML from source

Run with Python 3 (no third-party Python packages needed):

```sh
python3 build_upgrader.py --ips /path/to/UWNH_Test54c_CUMULATIVE_from_Clean_US_ROM_2026-11-16.ips --output UWNH_Test54c_Public_ROM_Free_Upgrader.html
```

The builder refuses an IPS that does not match the exact verified size and SHA-256. The builder **never reads any game ROM**.

## Testing and scope

This companion is an **upgrader only**, not the full World, Ship & Fleet Studio editor. The private editor should not be publicly distributed because it embeds commercial game data.

The included release passed offline Node tests using the exact clean source and IPS, wrong-size and altered ROMs, IPS tampering, and simulated browser controls/download. On **18 November 2026**, the project owner supplied real-browser screenshots confirming the correct input, successful verification, downloaded 4 MiB ROM and a successful Snes9x launch into Rimbo's opening scene. This verifies the installation path, but does not establish full gameplay stability.

**Credits:** Research, design and testing by Ken Chee (Realbrowncow); technical implementation in collaboration with ChatGPT.
