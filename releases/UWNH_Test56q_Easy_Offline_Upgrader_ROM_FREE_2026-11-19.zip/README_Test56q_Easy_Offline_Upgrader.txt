UNCHARTED WATERS: NEW HORIZONS — TEST56q EASY OFFLINE UPGRADER
Ken Chee / Realbrowncow | 19 November 2026

STATUS: Experimental Test56q release candidate; full 100-port gameplay testing
and long-session stability testing are not complete. Test54c remains public.

EASY METHOD (RECOMMENDED)
1. Extract this ZIP to any folder on your computer.
2. Double-click UWNH_Test56q_Easy_Offline_Upgrader.html to open it in Chrome, Edge, or Firefox.
3. Choose your own clean original US SNES ROM (2,097,152 bytes, no copier header).
4. Click 'Verify and Create Test56q'.
5. The tool verifies the original, applies the embedded IPS patch locally,
   checks the finished SHA-256, and downloads a new verified .smc file.
6. Keep your original untouched, and test the new ROM separately in an emulator.

This offline tool sends NO ROM data to any server, includes NO commercial ROM,
and works without an internet connection. It rejects other regions, altered,
headered, previously patched, or otherwise incorrect input files.

MANUAL IPS METHOD
Apply UWNH_Test56q_CUMULATIVE_from_Clean_US_ROM_2026-11-19.ips only to the exact clean original US ROM below
using an IPS patcher that supports run-length records and 4 MiB expansion.
Do NOT apply it to Test54c, Test55i or Test56n. Those need different patches.

REQUIRED ORIGINAL US ROM
Bytes: 2,097,152 (headerless)
SHA-256: 64bc4707f422661a66618088887e2363a5f896ea683c58984fffd96dd21ab5f0

EXPECTED TEST56q RESULT
Bytes: 4,194,304
SHA-256: a8e72f2b9c8db2be7e6f5c10852cd0282cc13b0eea681cc450e398ebaa5aff9b

CUMULATIVE IPS
Bytes: 129178
SHA-256: 15bf4dce91e070bc55c9134e1c55e9d91007a3c710dad83368662c7f44ecc2c9
Records: 2714

CAUTION
Test56q is a private-development release candidate; using a new game is
recommended. Do not reuse temporary Test56p SRAM or a Test56j freeze state.

Fan research only; not affiliated with Koei or Koei Tecmo. No commercial ROM
is included, and the game is not distributed by this package.
