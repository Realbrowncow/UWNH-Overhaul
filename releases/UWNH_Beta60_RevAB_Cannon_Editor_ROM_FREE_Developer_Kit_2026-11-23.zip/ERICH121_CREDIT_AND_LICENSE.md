# erich121 credit and license notice

The original **All Ten Ships Manual Control** feature and the New Horizons Editor ship-table work were developed by **erich121** and incorporated with attribution under the project's MIT license provisions. Keep the original upstream license text and copyright notices already embedded in the editor source.

In a sea battle, press **SELECT** in the battle command menu to switch mates between `Mates: AUTO ON.` (AI-controlled companions) and `Mates: AUTO OFF.` (manual control of ships 2–10). Press **A** to dismiss the message. The flagship remains manually controlled.

Official public WordPress instructions and download notes are **not updated yet**; Ken will authorize that separately.
