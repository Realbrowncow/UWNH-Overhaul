/** Core-only VM regression (DOM actions are deliberately stubbed, not gameplay). */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import crypto from 'node:crypto';
import vm from 'node:vm';
import {fileURLToPath} from 'node:url';

const dir=fileURLToPath(new URL('.',import.meta.url));
const root=fileURLToPath(new URL('..',import.meta.url));
const file=fs.readFileSync(dir+'New_Horizons_Overhaul_Studio_Beta_6_0_Rev_AB_Test57b5d_ROM_FREE_Source.html','utf8');
assert.match(file,/id="shipSection" style="display:none" aria-hidden="true"/);
assert.match(file,/Detailed field layout adapted from erich121/);
assert.match(file,/Every editable field uses our own guarded Test57b5d encoder/);
assert.match(file,/Cannon Editor · seven native types/);
assert.match(file,/Saker's always-available gate and Carronade's special shop conditions remain protected/);
for(const id of ['uw60CannonSelect','uw60CannonName','uw60CannonHull','uw60CannonCrew',
 'uw60CannonRange','uw60CannonPrice','uw60CannonGate','uw60CannonStage','uw60CannonRestore'])
 assert.equal([...file.matchAll(new RegExp('id="'+id+'"','g'))].length,1,'Duplicate cannon UI: '+id);
for(const id of ['t54cShip','t54cHull','t54cTack','t54cSail','t54cCapacity','t54cMaxGuns','t54cMinCrew','t54cMaxCrew','t54cBasePrice'])
 assert.equal([...file.matchAll(new RegExp('id="'+id+'"','g'))].length,1,'Duplicate ship UI: '+id);
const rom=new Uint8Array(fs.readFileSync(root+'UWNH_Test57b5d_Jamaica_Algiers_PirateLackeyDialogue_ONLY_EXPERIMENTAL_2026-11-22.smc'));
const hash=x=>crypto.createHash('sha256').update(Buffer.from(x)).digest('hex');
const expected='ffd8754ab67870b13dee0561fba3d4492f39eea9c6b00662e6f83d26d261bbc4';
const captures=[];
const stub={load:()=>{},outputEdits:()=>new Map(),snapshot:()=>null,importState:()=>{},verify:()=>({}),resetAll:()=>{}};
const ctx=vm.createContext({Uint8Array,Set,Map,Blob,Buffer,console,Number,Array,Object,
 uwSHA256:async x=>hash(x),UWIdentityCore:{inspect:x=>({body:x})},
 uwIdExportROM:x=>x.slice(),UW60Art:{...stub},UW60Walk:{...stub},UW60Text:{...stub},
 UW60Map:{...stub},UW60Mini:{...stub},
 $:id=>({textContent:''}),notice:()=>{},
 saveBlob:(blob,name)=>captures.push({blob,name}),
 uwChecksum:body=>{
  // SNES header bytes have a fixed combined sum of 510.
  let total=510;for(let i=0;i<body.length;i++)if(i<0xffdc||i>0xffdf)total=(total+body[i])&65535;
  body[0xffdc]=(~total)&255;body[0xffdd]=((~total)>>8)&255;
  body[0xffde]=total&255;body[0xffdf]=(total>>8)&255;
 },
 });
const extract=(start,end)=>{
 const a=file.indexOf(start);assert(a>=0,'Missing '+start);
 const b=file.indexOf(end,a);assert(b>a,'Missing end '+end);
 return file.slice(a,b);
};
const resAndShip=extract('const UW60Resale = (() => {','const UW54Core=(()=>{');
vm.runInContext(resAndShip,ctx);
let core=extract('const UW54Core=(()=>{','UW54Core.setup();');
const loadStart=core.indexOf(' async function load(input,label){');
const loadEnd=core.indexOf(' async function bundled(){',loadStart);
assert(loadStart>0&&loadEnd>loadStart);
core=core.slice(0,loadStart)+String.raw`
 async function load(input,label){
  const rom=input;
  if(rom.length!==0x400000)throw Error('Wrong ROM length');
  const hash=await uwSHA256(rom);
  if(hash!==SOURCE_SHA)throw Error('Wrong ROM hash');
  baseline=rom.slice();originLabel=label;staged=new Map();validOffsets=makeValidSet();
  resaleRate=UW60Resale.DEFAULT_RATE;assertCannonLayout();producerBaseline=decodeProducerBaseline();
  producerEdits=new Map();nameEdits=new Map();return {hash,bytes:rom.length};
 }
`+core.slice(loadEnd);
// Test staging and export logic, never the separate on-page GUI functions.
core=core.replace(' return {setup,load,bundled,snapshot,projectImport,buildOutput',
                  ' refreshAll=()=>{}; return {setup,load,bundled,snapshot,projectImport,buildOutput');
vm.runInContext(core,ctx);
const module=vm.runInContext('UW54Core',ctx);
assert.equal((await module.load(rom,'Test57b5d')).hash,expected);
assert.equal(module.verify().expectedSha,expected);
assert.equal(module.listNavigators().length,120);
assert.equal(module.getNavigatorStats(3).name,'Rimbo');
const output=module.buildOutput();
assert.equal(output.changed,0);
assert.equal(hash(output.out),expected);
assert.equal(module.getShipModel(0).name,'Sambuk');
assert.equal(module.getShipModel(11).name,'Jong');
assert.equal(module.getShipModel(11).basePrice,884000);
assert.equal(Array.from({length:25},(_,id)=>module.getShipModel(id)).length,25);
module.verifyShipModels();
assert.equal(module.getCannon(1).name,'Cannon');
assert.equal(module.getCannon(1).hullAttack,20);
assert.equal(module.getCannon(1).crewAttack,20);
assert.equal(module.getCannon(1).price,700);
assert.equal(module.getCannon(1).unlockSum,1000);
assert.equal(module.getCannon(6).name,'Saker');
assert.equal(module.getCannon(6).unlockSum,0);
assert.equal(module.getCannon(7).name,'Carronade');
assert.equal(module.getCannon(7).unlockSum,null);
assert.equal(module.getCannon(3).unlockSum,400);
assert.equal(module.getCannon(5).unlockSum,600);
assert.equal(module.getCannon(2).unlockSum,700);
assert.equal(module.getCannon(4).unlockSum,900);
module.verifyCannons();
// Each native cannon owns independent hull/crew/range/price records.
const cannonKeys=['hullAttack','crewAttack','range','price','unlockSum'];
const cannonForm=id=>Object.fromEntries(cannonKeys.map(k=>[k,module.getCannon(id)[k]]));
const editedCannonBytes=new Set();
const cannonBases=[0x0b092b,0x0b093b,0x0b094b,0x0b095b];
for(let id=1;id<=7;id++){
 const current=cannonForm(id);
 module.stageCannon(id,{...current,hullAttack:current.hullAttack+1,
  crewAttack:current.crewAttack+2,range:current.range+1,price:current.price+1});
 for(const base of cannonBases){editedCannonBytes.add(base+2*(id-1));editedCannonBytes.add(base+2*(id-1)+1);}
}
const cannonGates=[0x233a17,0x233a12,0x233a0d,0x233a08,0x233a03];
const cannonGateIds=[3,5,2,4,1];
for(let i=0;i<cannonGateIds.length;i++){
 const id=cannonGateIds[i],c=cannonForm(id);
 module.stageCannon(id,{...c,unlockSum:c.unlockSum+1});
 editedCannonBytes.add(cannonGates[i]);editedCannonBytes.add(cannonGates[i]+1);
}
const cannonOutput=module.buildOutput();
assert(cannonOutput.changed>0);
for(let i=0;i<rom.length;i++)if(i<0xffdc||i>0xffdf)
 if(!editedCannonBytes.has(i))assert.equal(cannonOutput.out[i],rom[i],
  'Cannon changes wrote outside native table/gate bytes at '+i.toString(16));
const cannonSaved=JSON.parse(JSON.stringify(module.snapshot()));
assert.throws(()=>module.stageCannon(6,{...cannonForm(6),unlockSum:25}),/protected/);
assert.throws(()=>module.stageCannon(7,{...cannonForm(7),unlockSum:500}),/protected/);
assert.throws(()=>module.stageCannon(5,{...cannonForm(5),unlockSum:710}),/must ascend/);
assert.throws(()=>module.stageCannon(1,{...cannonForm(1),price:10000}),/1 to 9999/);
assert.deepEqual(Buffer.from(module.buildOutput().out),Buffer.from(cannonOutput.out));
for(let id=1;id<=7;id++)module.restoreCannon(id);
assert.equal(module.buildOutput().changed,0);
module.projectImport(cannonSaved);
assert.deepEqual(Buffer.from(module.buildOutput().out),Buffer.from(cannonOutput.out));
const cannonTampered=JSON.parse(JSON.stringify(cannonSaved));
const badCannonByte=cannonTampered.byteEdits.find(([at])=>at===0x0b092b);
assert(badCannonByte);badCannonByte[1]=0;
assert.throws(()=>module.projectImport(cannonTampered),/Hull attack/);
assert.deepEqual(Buffer.from(module.buildOutput().out),Buffer.from(cannonOutput.out));
const gateTampered=JSON.parse(JSON.stringify(cannonSaved));
const badGate=gateTampered.byteEdits.find(([at])=>at===0x233a12);
assert(badGate);badGate[1]=255;
assert.throws(()=>module.projectImport(gateTampered),/must be strictly increasing|must be an integer/);
assert.deepEqual(Buffer.from(module.buildOutput().out),Buffer.from(cannonOutput.out));
for(let id=1;id<=7;id++)module.restoreCannon(id);
assert.equal(module.buildOutput().changed,0);

// Edit every kind of permitted ship field using ONLY the new Test57b5d core.
const jong=module.getShipModel(11);
const shipKeys=['hull','tacking','sailing','maxCrew','minCrew','capacity','maxGuns','basePrice'];
const shipForm=Object.fromEntries(shipKeys.map(k=>[k,jong[k]]));
const alteredShip={...shipForm,hull:jong.hull+1,tacking:jong.tacking+1,
 sailing:jong.sailing+1,maxCrew:jong.maxCrew-10,minCrew:jong.minCrew-1,
 capacity:jong.capacity+20,maxGuns:jong.maxGuns+1,basePrice:jong.basePrice+10};
module.stageShipModel(11,alteredShip);
assert.equal(module.getShipModel(11).hull,alteredShip.hull);
assert.equal(module.getShipModel(11).basePrice,alteredShip.basePrice);
const shipOutput=module.buildOutput();
const spec=0x08ce27+12*11,price=0x3e8100+4*11;
const shipAllowed=new Set([...Array.from({length:8},(_,i)=>spec+i+1),
 ...Array.from({length:4},(_,i)=>price+i)]);
for(let i=0;i<rom.length;i++)if(i<0xffdc||i>0xffdf)
 if(!shipAllowed.has(i))assert.equal(shipOutput.out[i],rom[i],
  'Ship change wrote outside our guarded fields: '+i.toString(16));
const sourceModel=0x08cbb6+25*11;
assert.deepEqual(Buffer.from(shipOutput.out.slice(sourceModel,sourceModel+25)),
 Buffer.from(rom.slice(sourceModel,sourceModel+25)),'Factory data/name changed');
const badShip={...alteredShip,maxCrew:95};
assert.throws(()=>module.stageShipModel(11,badShip),/multiple of ten/);
assert.deepEqual(Buffer.from(module.buildOutput().out),Buffer.from(shipOutput.out));
const shipSnapshot=JSON.parse(JSON.stringify(module.snapshot()));
module.restoreShipModel(11);
assert.equal(module.buildOutput().changed,0);
module.projectImport(shipSnapshot);
assert.deepEqual(Buffer.from(module.buildOutput().out),Buffer.from(shipOutput.out));
const badShipSnapshot=JSON.parse(JSON.stringify(shipSnapshot));
const crewEntry=badShipSnapshot.byteEdits.find(([at])=>at===spec+4);
assert(crewEntry);crewEntry[1]=0;
assert.throws(()=>module.projectImport(badShipSnapshot),/Maximum crew/);
assert.deepEqual(Buffer.from(module.buildOutput().out),Buffer.from(shipOutput.out));
module.restoreShipModel(11);
assert.equal(module.buildOutput().changed,0);

const keepDuel=rom.slice(0x34a000,0x350000);
const a=module.getNavigatorStats(3),b=module.getNavigatorStats(109);
const fields=['leadership','seamanship','knowledge','intuition','courage','swordsmanship','charm','luck','navigation_level','battle_level','skills'];
const make=x=>Object.fromEntries(fields.map(k=>[k,x[k]]));
const editA=make(a),editB=make(b);
editA.leadership=(editA.leadership+1)%101;editA.skills^=1;
editB.courage=(editB.courage+1)%101;editB.battle_level=editB.battle_level===100?99:editB.battle_level+1;
module.stageNavigatorStats(3,editA);module.stageNavigatorStats(109,editB);
assert.deepEqual(module.getNavigatorStats(3).leadership,editA.leadership);
assert.deepEqual(module.getNavigatorStats(109).battle_level,editB.battle_level);
const both=module.buildOutput();
assert(both.changed>0);
await module.exportFile('ips');
assert.equal(captures.length,1);
assert.match(captures[0].name,/Test57b5d.*RevAB.*\.ips$/);
const patchBytes=new Uint8Array(await captures[0].blob.arrayBuffer());
assert.equal(Buffer.from(patchBytes.subarray(0,5)).toString(),'PATCH');
const replay=rom.slice();let pos=5;
while(pos<patchBytes.length-3){
 const at=(patchBytes[pos]<<16)|(patchBytes[pos+1]<<8)|patchBytes[pos+2];
 const n=(patchBytes[pos+3]<<8)|patchBytes[pos+4];pos+=5;
 assert(n>0&&at+n<=replay.length);replay.set(patchBytes.subarray(pos,pos+n),at);pos+=n;
}
assert.equal(Buffer.from(patchBytes.subarray(pos)).toString(),'EOF');
assert.deepEqual(Buffer.from(replay),Buffer.from(both.out));
assert.deepEqual(Buffer.from(both.out.slice(0x34a000,0x350000)),Buffer.from(keepDuel));
const allowed=new Set([28,48].map(offset=>0x0881f3+50*3+offset)
 .concat([32,37].map(offset=>0x0881f3+50*109+offset)));
for(let i=0;i<rom.length;i++)if(i<0xffdc||i>0xffdf)
 if(!allowed.has(i))assert.equal(both.out[i],rom[i],'Unauthorized output byte at '+i.toString(16));
const saved=JSON.parse(JSON.stringify(module.snapshot()));
module.restoreNavigatorStats(3);module.restoreNavigatorStats(109);
assert.equal(module.buildOutput().changed,0);
module.projectImport(saved);
assert.deepEqual(Buffer.from(module.buildOutput().out),Buffer.from(both.out));
const invalid=JSON.parse(JSON.stringify(saved));
const level=invalid.byteEdits.find(([at])=>at===0x0881f3+50*109+37);
assert(level);level[1]=101;
assert.throws(()=>module.projectImport(invalid));
assert.deepEqual(Buffer.from(module.buildOutput().out),Buffer.from(both.out));
module.restoreNavigatorStats(3);module.restoreNavigatorStats(109);
module.stageDuelEquipment([7,12,13,74,73,76,16,17,19]);
assert(module.buildOutput().changed>0);
module.restoreDuelEquipment();
assert.equal(module.buildOutput().changed,0);
module.setResaleRate(20);
assert(module.buildOutput().changed>0);
module.setResaleRate(10);
assert.equal(module.buildOutput().changed,0);
await assert.rejects(module.load(rom.slice(0,0x200000),'Invalid'),/Wrong ROM length/);
console.log(JSON.stringify({status:'CORE STATIC PASS',baseline:'Test57b5d',unchangedExact:true,
 all25Ships:true,unifiedShipLayout:true,eightGuardedShipFields:true,factoryRecordsPreserved:true,
 allSevenCannons:true,independentNativeAttackTables:true,editableOrderedShopGates:true,
 protectedSpecialCarronade:true,cannonStageRestoreAndProjectRoundtrip:true,cannonWriteIsolation:true,
 navigators:120,independentStats:true,duelCodePreserved:true,settingsRoundtrip:true,
 tamperedSettingsRefused:true,equipmentRestored:true,resaleRestored:true,
 exportedIPSReplays:true,invalidRomRefused:true},null,2));
