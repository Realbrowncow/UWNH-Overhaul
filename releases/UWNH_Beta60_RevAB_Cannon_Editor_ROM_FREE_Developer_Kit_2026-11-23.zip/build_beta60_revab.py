#!/usr/bin/env python3
"""Rev AB: guarded native Test57b5d cannon stats, price and shop unlock gates."""
from pathlib import Path
import hashlib
import re

HERE = Path(__file__).resolve().parent
PREV = HERE.parent / 'beta60_revaa'
BASE = 'New_Horizons_Overhaul_Studio_Beta_6_0_Rev_'


def replace_once(source, old, new, name):
    count = source.count(old)
    if count != 1:
        raise ValueError(f'{name}: expected one occurrence, found {count}')
    return source.replace(old, new, 1)


CANNON_PANEL = '''<details id="uw60CannonSection" style="margin-top:10px" open>
 <summary class="kicker" style="cursor:pointer">Cannon Editor · seven native types (Test57b5d)</summary>
 <p class="hint">Edit a cannon's <b>hull attack</b>, <b>crew attack</b>, <b>range</b>, <b>price per gun</b> and, where available, the <b>minimum Economy + Industry</b> for shop availability. All values are read from the authoritative Test57b5d image; the original game remains untouched until you export. The two native attack tables are independent.</p>
 <label class="kicker" for="uw60CannonSelect">Cannon type<select id="uw60CannonSelect" style="width:100%;padding:8px"></select></label>
 <div class="shipfields">
  <label>Native cannon name (protected)<input id="uw60CannonName" readonly></label>
  <label>Hull attack (1–99)<input id="uw60CannonHull" type="number" min="1" max="99" step="1"></label>
  <label>Crew attack (1–99)<input id="uw60CannonCrew" type="number" min="1" max="99" step="1"></label>
  <label>Battle range (1–8)<input id="uw60CannonRange" type="number" min="1" max="8" step="1"></label>
  <label>Price per gun (1–9999 ducats)<input id="uw60CannonPrice" type="number" min="1" max="9999" step="1"></label>
  <label>Shop gate · Economy + Industry<input id="uw60CannonGate" type="number" min="1" max="2000" step="1"></label>
 </div>
 <p class="hint" id="uw60CannonGateInfo" role="note"></p>
 <div class="portbtns"><button class="btn primary" id="uw60CannonStage">Stage this cannon</button><button class="btn" id="uw60CannonRestore">Restore this cannon</button></div>
 <p class="hint" id="uw60CannonStatus" role="status"></p>
 <p class="hint warn"><b>Guarded experiment:</b> Baseline cannon names and their formatting/pointers cannot be renamed here. Saker's always-available gate and Carronade's special shop conditions remain protected. The five editable shop thresholds must stay strictly increasing in native shop order. The attack/range/price tables and five existing comparison operands are the only cannon bytes allowed to change. Test range, combat and shop prices in a new game before promotion.</p>
</details>
'''

CANNON_CORE = r'''
 // Native CB bank cannon records. ID zero is the empty entry; editable IDs are 1–7.
 // Two distinct attack tables exist in the unmodified US ROM. Test57b5d
 // currently happens to give them equal values for each of its seven cannons.
 const CANNON_NAMES=['','Cannon','Demi-cannon','Canon Pedrero','Culverin','Demi-culverin','Saker','Carronade'];
 const CANNON_TABLES={hullAttack:0x0B092B,range:0x0B093B,crewAttack:0x0B094B,price:0x0B095B};
 // The existing E3:3A00 shop routine is a chain of 16-bit CMP immediates.
 // IDs 6/7 have their own protected always-available/special gate paths.
 const CANNON_GATE_PC=[null,0x233A03,0x233A0D,0x233A17,0x233A08,0x233A12,null,null];
 const CANNON_GATE_ORDER=[3,5,2,4,1];
 const CANNON_FIELDS=['hullAttack','crewAttack','range','price','unlockSum'];
 function cannonAt(field,id){return CANNON_TABLES[field]+2*(rangeInt(id,1,7,'Cannon ID')-1);}
 function assertCannonLayout(){
  assertLoaded();
  const expected={hullAttack:[20,16,12,14,10,8,20],range:[3,2,3,5,4,2,4],
   crewAttack:[20,16,12,14,10,8,20],price:[700,500,400,800,600,100,900]};
  for(const field of Object.keys(CANNON_TABLES)){
   const base=CANNON_TABLES[field];
   if(baseline[base-2]!==0||baseline[base-1]!==0||
      (field!=='price'&&(baseline[base+14]!==0||baseline[base+15]!==0)))
    throw Error('Unexpected native cannon table framing: '+field);
   for(let id=1;id<=7;id++){
    const at=cannonAt(field,id);
    if((baseline[at]|baseline[at+1]<<8)!==expected[field][id-1])
     throw Error('Unexpected native Test57b5d '+field+' entry #'+id);
   }
  }
  if(baseline[0x233A00]!==0xA5||baseline[0x233A01]!==0||baseline[0x233A02]!==0xC9)
   throw Error('Unexpected cannon unlock routine');
  for(const id of CANNON_GATE_ORDER){const at=CANNON_GATE_PC[id];
   if(baseline[at-1]!==0xC9||baseline[at+2]!==0xB0)
    throw Error('Unexpected cannon gate instruction for '+CANNON_NAMES[id]);
  }
  if(CANNON_GATE_ORDER.map(id=>baseline[CANNON_GATE_PC[id]]|(baseline[CANNON_GATE_PC[id]+1]<<8)).join(',')!==
    '400,600,700,900,1000')throw Error('Unexpected original cannon shop thresholds');
 }
 function getCannon(id,original=false){
  assertLoaded();id=rangeInt(id,1,7,'Cannon ID');const read=original?at=>baseline[at]:read8;
  const word=at=>read(at)|(read(at+1)<<8);
  const row={id,name:CANNON_NAMES[id]};
  for(const field of Object.keys(CANNON_TABLES))row[field]=word(cannonAt(field,id));
  row.unlockSum=id===6?0:id===7?null:word(CANNON_GATE_PC[id]);
  return row;
 }
 function validateCannon(id,row){
  id=rangeInt(id,1,7,'Cannon ID');
  if(!row||typeof row!=='object'||Array.isArray(row)||
   Object.keys(row).length!==CANNON_FIELDS.length||CANNON_FIELDS.some(key=>!Object.hasOwn(row,key)))
   throw Error('Complete cannon fields are required.');
  rangeInt(row.hullAttack,1,99,'Hull attack');
  rangeInt(row.crewAttack,1,99,'Crew attack');
  rangeInt(row.range,1,8,'Cannon range');
  rangeInt(row.price,1,9999,'Cannon price');
  if(CANNON_GATE_PC[id]===null){
   if(row.unlockSum!==(id===6?0:null))throw Error('Saker/Carronade unlock rules are protected.');
  }else rangeInt(row.unlockSum,1,2000,'Cannon shop gate');
  return row;
 }
 function verifyCannons(){
  assertLoaded();let previous=0;
  for(let id=1;id<=7;id++){
   const row=getCannon(id);validateCannon(id,Object.fromEntries(CANNON_FIELDS.map(k=>[k,row[k]])));
  }
  for(const id of CANNON_GATE_ORDER){
   const gate=getCannon(id).unlockSum;
   if(gate<=previous)throw Error('Cannon shop unlock thresholds must be strictly increasing (Pedrero, Demi-culverin, Demi-cannon, Culverin, Cannon).');
   previous=gate;
  }
 }
 function stageCannon(id,fields){
  assertLoaded();id=rangeInt(id,1,7,'Cannon ID');validateCannon(id,fields);
  // Check prospective gate ordering before staging any bytes.
  const gates=CANNON_GATE_ORDER.map(other=>other===id?fields.unlockSum:getCannon(other).unlockSum);
  if(gates.some((v,i)=>i>0&&v<=gates[i-1]))
   throw Error('Shop gates must ascend: Pedrero < Demi-culverin < Demi-cannon < Culverin < Cannon.');
  for(const field of Object.keys(CANNON_TABLES))stage16(cannonAt(field,id),fields[field]);
  if(CANNON_GATE_PC[id]!==null)stage16(CANNON_GATE_PC[id],fields.unlockSum);
  verifyCannons();refreshAll();
 }
 function restoreCannon(id){
  assertLoaded();id=rangeInt(id,1,7,'Cannon ID');
  for(const field of Object.keys(CANNON_TABLES)){
   const at=cannonAt(field,id);stage16(at,baseline[at]|baseline[at+1]<<8);
  }
  if(CANNON_GATE_PC[id]!==null){const at=CANNON_GATE_PC[id];stage16(at,baseline[at]|baseline[at+1]<<8);}
  verifyCannons();refreshAll();
 }
 function refreshCannon(){
  if(!loaded())return;const id=Number($('uw60CannonSelect').value),r=getCannon(id);
  for(const [key,input] of [['name','uw60CannonName'],['hullAttack','uw60CannonHull'],
   ['crewAttack','uw60CannonCrew'],['range','uw60CannonRange'],['price','uw60CannonPrice']])
   $(input).value=String(r[key]);
  const editable=CANNON_GATE_PC[id]!==null;
  $('uw60CannonGate').disabled=!editable;
  $('uw60CannonGate').value=editable?String(r.unlockSum):'';
  $('uw60CannonGate').placeholder=id===6?'Always available':'Special Carronade rules';
  $('uw60CannonGateInfo').textContent=editable
   ? 'Requires Economy + Industry ≥ '+r.unlockSum+' (other native gates must remain in ascending order).'
   : id===6?'Saker: always available; its native gate cannot be edited.'
    :'Carronade: special native shop conditions remain protected.';
  const changed=Object.keys(CANNON_TABLES).some(k=>r[k]!==getCannon(id,true)[k])||
   (editable&&r.unlockSum!==getCannon(id,true).unlockSum);
  $('uw60CannonStatus').textContent='#'+id+' · '+r.name+' · '+(changed?'Staged changes':'Original Test57b5d values')+
   ' · no ROM data modified until export.';
 }
 function stageCannonSelected(){
  const id=Number($('uw60CannonSelect').value),fields={};
  for(const [key,input] of [['hullAttack','uw60CannonHull'],['crewAttack','uw60CannonCrew'],
   ['range','uw60CannonRange'],['price','uw60CannonPrice']]){
   const value=$(input).value.trim();if(!value)throw Error('Missing cannon '+key);
   fields[key]=Number(value);
  }
  if(CANNON_GATE_PC[id]!==null){const text=$('uw60CannonGate').value.trim();
   if(!text)throw Error('Missing cannon shop gate');fields.unlockSum=Number(text);
  }else fields.unlockSum=id===6?0:null;
  stageCannon(id,fields);
 }
'''


def upgrade(source):
    source = replace_once(source,
        ' <details><summary class="kicker" style="cursor:pointer">Reference-only · Fleets, stocks, cannons and sprites</summary>',
        CANNON_PANEL+'\n <details><summary class="kicker" style="cursor:pointer">Reference-only · Fleets, stocks and sprites</summary>',
        'insert cannon form')
    source = replace_once(source,
        'These systems are incorporated in the bundled Test57b5d bytes, but modifying them reliably requires the specialized code and workbooks.',
        'The fleet-generation rules and unexposed sprite routines remain protected. The seven native cannon stats, prices and five shop gates now have a separate guarded editor above.',
        'reference panel scope')
    source = replace_once(source,
        ' function stage8(at,val){', CANNON_CORE+'\n function stage8(at,val){',
        'insert cannon core')
    source = replace_once(source,
        '  add(DUEL_PC,10); // Exact native NPC duel-equipment table only.',
        '''  add(DUEL_PC,10); // Exact native NPC duel-equipment table only.
  for(const field of Object.keys(CANNON_TABLES))add(CANNON_TABLES[field],14);
  for(const id of CANNON_GATE_ORDER)add(CANNON_GATE_PC[id],2);''',
        'cannon allowlist')
    source = replace_once(source,
        "  const rules=$('t54cRule');rules.replaceChildren();",
        "  const cannons=$('uw60CannonSelect');cannons.replaceChildren();for(let id=1;id<=7;id++)cannons.append(makeOption(id,id+' · '+CANNON_NAMES[id]));cannons.value='1';\n  const rules=$('t54cRule');rules.replaceChildren();",
        'cannon select choices')
    source = replace_once(source,
        'refreshResale();refreshShip();refreshPort();',
        'refreshResale();refreshShip();refreshCannon();refreshPort();',
        'cannon UI refresh')
    source = replace_once(source,
        '  producerBaseline=decodeProducerBaseline();producerEdits=new Map();nameEdits=new Map();',
        '  assertCannonLayout();producerBaseline=decodeProducerBaseline();producerEdits=new Map();nameEdits=new Map();',
        'verified cannon layout on load')
    source = replace_once(source,
        'checkRare();verifyPortDevelopment();verifyDuelEquipment();verifyNavigatorStats();verifyShipModels();UW60ShipPrice.verifyTable(read8);',
        'checkRare();verifyPortDevelopment();verifyDuelEquipment();verifyNavigatorStats();verifyShipModels();verifyCannons();UW60ShipPrice.verifyTable(read8);',
        'settings cannon validation')
    source = replace_once(source,
        'checkRare();verifyPortDevelopment();verifyProducerEdits();verifyDuelEquipment();verifyNavigatorStats();verifyShipModels();UW60ShipPrice.verifyTable(read8);',
        'checkRare();verifyPortDevelopment();verifyProducerEdits();verifyDuelEquipment();verifyNavigatorStats();verifyShipModels();verifyCannons();UW60ShipPrice.verifyTable(read8);',
        'export cannon validation')
    source = replace_once(source,
        "  $('t54cShipApply').onclick=handle(stageShip);",
        "  $('uw60CannonSelect').onchange=refreshCannon;\n  $('uw60CannonStage').onclick=handle(stageCannonSelected);\n  $('uw60CannonRestore').onclick=handle(()=>restoreCannon(Number($('uw60CannonSelect').value)));\n  $('t54cShipApply').onclick=handle(stageShip);",
        'cannon button handlers')
    source = replace_once(source,
        ' getShipModel,stageShipModel,restoreShipModel,verifyShipModels,getNavigatorFace:',
        ' getShipModel,stageShipModel,restoreShipModel,verifyShipModels,\n getCannon,stageCannon,restoreCannon,verifyCannons,assertCannonLayout,getNavigatorFace:',
        'public cannon API')
    source = source.replace('Beta 6.0 Rev AA','Beta 6.0 Rev AB').replace('Rev AA','Rev AB')\
                   .replace('RevAA','RevAB').replace('Rev_AA','Rev_AB')
    if source.count('id="uw60CannonSelect"') != 1:
        raise ValueError('duplicate cannon select')
    if 'Original All Ten Ships Manual Control feature by <b>erich121</b>' not in source:
        raise ValueError('manual control attribution lost')
    return source


def remove_commercial_terrain_seed(source):
    """Public HTML must not include the original 2160x1080 ROM-derived map."""
    pattern=r'(<script id="seed" type="text/plain">)[^<]*(</script>)'
    source,n=re.subn(pattern,r'\1\2',source)
    if n!=1:raise ValueError('Expected one bundled terrain seed in public source')
    source=replace_once(source,
        "async function init(){try{const seed=$('seed').textContent.trim(),compressed=base64ToBytes(seed);",
        "async function init(){try{const seed=$('seed').textContent.trim();if(!seed){resize();fit();$('intro').style.opacity='1';$('status').textContent='ROM-free release · load a verified US ROM to view the map';notice('Public edition has no bundled game map. Load your US SNES ROM or upgraded Test57b5d ROM to view terrain.',false,9000);return;}const compressed=base64ToBytes(seed);",
        'public no-terrain startup')
    return source


def main():
    for kind in ('PRIVATE','ROM_FREE_Source'):
        previous=PREV/(BASE+'AA_Test57b5d_'+kind+'.html')
        target=HERE/(BASE+'AB_Test57b5d_'+kind+'.html')
        text=upgrade(previous.read_text(encoding='utf-8'))
        if kind=='ROM_FREE_Source':text=remove_commercial_terrain_seed(text)
        target.write_text(text,encoding='utf-8')
        print(target.name, target.stat().st_size, hashlib.sha256(target.read_bytes()).hexdigest())


if __name__=='__main__':
    main()
