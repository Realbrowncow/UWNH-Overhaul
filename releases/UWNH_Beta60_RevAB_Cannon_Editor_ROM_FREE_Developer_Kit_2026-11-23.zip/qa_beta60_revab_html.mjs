/** HTML/embedded-ROM guard. Static syntax checks; not a browser/gameplay test. */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import crypto from 'node:crypto';
import zlib from 'node:zlib';
import {fileURLToPath} from 'node:url';

const dir=fileURLToPath(new URL('.',import.meta.url));
const prefix='New_Horizons_Overhaul_Studio_Beta_6_0_Rev_AB_Test57b5d_';
const privateHtml=fs.readFileSync(dir+prefix+'PRIVATE.html','utf8');
const publicHtml=fs.readFileSync(dir+prefix+'ROM_FREE_Source.html','utf8');
const scripts=html=>[...html.matchAll(/<script\b([^>]*)>([\s\S]*?)<\/script>/gi)];
for(const [type,html] of [['PRIVATE',privateHtml],['ROM_FREE',publicHtml]]){
 let count=0;
 for(const [,attrs,body] of scripts(html)){
  if(/\btype\s*=\s*["'](?:application\/json|text\/plain)["']/i.test(attrs))continue;
  if(/\bsrc\s*=/i.test(attrs))continue;
  new vm.Script(body,{filename:type+'.script.'+(++count)+'.js'});
 }
 assert(count>=5,'Expected executable scripts in '+type);
 assert.match(html,/id="uw60CannonSection"/);
 assert.match(html,/Original All Ten Ships Manual Control feature by <b>erich121<\/b>/);
}
const bundle=(html,id)=>{
 const escaped=id.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
 const match=html.match(new RegExp('<script id="'+escaped+'"[^>]*>([\\s\\S]*?)<\\/script>'));
 assert(match,'Missing '+id);return match[1].trim();
};
for(const id of ['seed','test56q-rom-bundle','test44-rom-bundle'])
 assert.equal(bundle(publicHtml,id),'','ROM-free HTML accidentally bundles game data: '+id);
const zipped=Buffer.from(bundle(privateHtml,'test56q-rom-bundle'),'base64');
const rom=zlib.inflateSync(zipped);
assert.equal(rom.length,0x400000);
assert.equal(crypto.createHash('sha256').update(rom).digest('hex'),
 'ffd8754ab67870b13dee0561fba3d4492f39eea9c6b00662e6f83d26d261bbc4');
console.log(JSON.stringify({status:'HTML STATIC PASS',privateAndPublicSyntax:true,
 privateBundleExactTest57b5d:true,publicHTMLRomFree:true,publicTerrainSeedEmpty:true,
 erich121CreditPreserved:true},null,2));
