/** Verify both embedded IPS stages with Ken's exact original and target ROMs. */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import crypto from 'node:crypto';
import {fileURLToPath} from 'node:url';

const base=fileURLToPath(new URL('.',import.meta.url));
const parent=fileURLToPath(new URL('..',import.meta.url));
const html=fs.readFileSync(base+'New_Horizons_Overhaul_Studio_Beta_6_0_Rev_AB_Test57b5d_ROM_FREE_Source.html','utf8');
const clean=new Uint8Array(fs.readFileSync(parent+'../Uncharted Waters - New Horizons (U).smc'));
const actual=new Uint8Array(fs.readFileSync(parent+'UWNH_Test57b5d_Jamaica_Algiers_PirateLackeyDialogue_ONLY_EXPERIMENTAL_2026-11-22.smc'));
const tag=id=>{
 const regex=new RegExp('<script id="'+id+'" type="text/plain">(.*?)<\\/script>','s');
 const match=html.match(regex);
 assert(match,'Missing script tag: '+id);
 return match[1];
};
const digest=x=>crypto.createHash('sha256').update(Buffer.from(x)).digest('hex');
const source=html.split('const UW54Upgrade = (() => {')[1]?.split('UW54Upgrade.setup();')[0];
assert(source);
const context=vm.createContext({Uint8Array,Blob,Buffer,
  $:id=>({textContent:tag(id)}),
  base64ToBytes:s=>Uint8Array.from(Buffer.from(s,'base64')),
  uwSHA256:async x=>digest(x)});
vm.runInContext('const UW54Upgrade = (() => {'+source,context);
const upgrade=vm.runInContext('UW54Upgrade',context);
assert.equal(clean.length,0x200000);
assert.equal(digest(clean),'64bc4707f422661a66618088887e2363a5f896ea683c58984fffd96dd21ab5f0');
const oldStage=upgrade.parseAndApplyIPS(clean,Uint8Array.from(Buffer.from(tag('test56q-retail-upgrade-ips'),'base64')));
assert.equal(digest(oldStage.out),'a8e72f2b9c8db2be7e6f5c10852cd0282cc13b0eea681cc450e398ebaa5aff9b');
const result=await upgrade.upgradeBytes(clean);
assert.equal(result.sha256,'ffd8754ab67870b13dee0561fba3d4492f39eea9c6b00662e6f83d26d261bbc4');
assert.equal(result.sha256,digest(actual));
assert.deepEqual(Buffer.from(result.rom),Buffer.from(actual));
await assert.rejects(upgrade.upgradeBytes(new Uint8Array(0x200000)),/does not match/);
await assert.rejects(upgrade.upgradeBytes(new Uint8Array(0x200200)),/512-byte headers/);
console.log(JSON.stringify({status:'PASS',cleanToTest56qExact:true,test56qToTest57b5dExact:true,
 test57b5dROMByteIdentical:true,cleanSourceGuard:true,headerGuard:true,records:result.records},null,2));
